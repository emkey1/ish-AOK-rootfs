TARGETS = mountkernfs.sh udev mountdevsubfs.sh urandom mountall.sh mountall-bootclean.sh hwclock.sh brightness hostname.sh mountnfs.sh mountnfs-bootclean.sh bootmisc.sh checkroot.sh bootlogd mount-configfs kmod checkfs.sh checkroot-bootclean.sh stop-bootlogd-single
INTERACTIVE = checkroot.sh checkfs.sh
udev: mountkernfs.sh
mountdevsubfs.sh: mountkernfs.sh
urandom: mountall.sh mountall-bootclean.sh hwclock.sh
mountall.sh: checkfs.sh checkroot-bootclean.sh
mountall-bootclean.sh: mountall.sh
hwclock.sh: bootlogd
brightness: mountall.sh mountall-bootclean.sh
hostname.sh: bootlogd
mountnfs.sh: mountall.sh mountall-bootclean.sh
mountnfs-bootclean.sh: mountall.sh mountall-bootclean.sh mountnfs.sh
bootmisc.sh: mountall-bootclean.sh mountnfs.sh mountnfs-bootclean.sh checkroot-bootclean.sh
checkroot.sh: mountdevsubfs.sh hostname.sh bootlogd
bootlogd: mountdevsubfs.sh
mount-configfs: mountkernfs.sh kmod
kmod: checkroot.sh
checkfs.sh: checkroot.sh
checkroot-bootclean.sh: checkroot.sh
stop-bootlogd-single: mountall.sh mountall-bootclean.sh
