# iSH-AOK: default to a UTF-8 locale when nothing else named one.
# Reaches sessions PAM never touches -- ssh (stock sshd has UsePAM no).
[ -n "${LANG:-}" ] || export LANG=C.UTF-8
