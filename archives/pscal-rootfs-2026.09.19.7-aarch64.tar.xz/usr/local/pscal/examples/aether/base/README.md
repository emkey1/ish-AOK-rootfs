# Aether base examples

This directory contains small Aether programs that run with the current
bootstrap frontend:

For a larger multi-file example, see `examples/showcase`.

```sh
./build/bin/aether examples/base/hello
./build/bin/aether examples/base/control_flow
./build/bin/aether examples/base/effects_contracts
./build/bin/aether examples/base/contracts
./build/bin/aether examples/base/contract_layouts
./build/bin/aether examples/base/pure_functions
./build/bin/aether examples/base/parallel_calls
./build/bin/aether examples/base/task_helpers
./build/bin/aether examples/base/ai_helpers
./build/bin/aether examples/base/inferred_decls
./build/bin/aether examples/base/function_inference
./build/bin/aether examples/base/object_inference
./build/bin/aether examples/base/for_range
./build/bin/aether examples/base/loop_forms
./build/bin/aether examples/base/loop_forms_foreach
./build/bin/aether examples/base/module_demo
./build/bin/aether examples/base/module_consts_demo
./build/bin/aether examples/base/toon_blocks
./build/bin/aether examples/base/toon_access
./build/bin/aether examples/base/toon_handles
./build/bin/aether examples/base/toon_typed_handles
./build/bin/aether examples/base/toon_rebind
./build/bin/aether examples/base/toon_scalar_bindings
./build/bin/aether examples/base/toon_scalar_rebind
./build/bin/aether examples/base/toon_scalar_alias
./build/bin/aether examples/base/toon_key_vars
./build/bin/aether examples/base/toon_parse_payloads
./build/bin/aether examples/base/toon_parse_file
./build/bin/aether examples/base/toon_shape_scalars
./build/bin/aether examples/base/toon_real_scalars
./build/bin/aether examples/base/toon_type_checks
./build/bin/aether examples/base/toon_presence_checks
./build/bin/aether examples/base/toon_defaults
./build/bin/aether examples/base/cost_annotations
./build/bin/aether examples/base/toon_variable_parse
./build/bin/aether examples/base/type_blocks
./build/bin/aether examples/base/type_init
./build/bin/aether examples/base/self_alias
./build/bin/aether examples/base/self_mutation
./build/bin/aether examples/base/number_formatting
./build/bin/aether examples/base/real_to_text
./build/bin/aether examples/base/random_values
./build/bin/aether examples/base/strings
./build/bin/aether examples/base/dynamic_arrays
./build/bin/aether examples/base/nested_arrays
./build/bin/aether examples/base/text_processing
./build/bin/aether examples/base/tuple_returns
./build/bin/aether examples/base/bitwise_ops
./build/bin/aether examples/base/branching
./build/bin/aether examples/base/file_io
./build/bin/aether examples/base/sockets
./build/bin/aether examples/base/parsing
./build/bin/aether examples/base/clamp_minmax
./build/bin/aether examples/base/recursion
./build/bin/aether examples/base/text_var_builtins
./build/bin/aether examples/base/barnsley_fern
```

These examples stay within the currently supported Aether Core subset:

- `const` and `let` declarations with types
- initialized `const` declarations without types
- initialized `let` declarations without types when the initializer has an
  obvious source-level type such as a literal, compact helper return, or a
  previously known binding
- `fn ... -> Type`
- `ret`
- `if` and `while` without mandatory parentheses
- `fx { ... }`
- known effectful builtins such as `write`, `writeln`, `printf`, `readln`,
  `halt`, and thread-launch helpers require `fx`
- Aether-native `print(...)` and `println(...)` spellings lowered onto the
  shared `write` and `writeln` builtins
- `ai_chat(...)` lowered onto the shared OpenAI chat-completions builtin for
  compact agent/tooling-oriented source
- compact task/thread helpers such as `task_spawn`, `task_queue`, `task_wait`,
  `task_lookup`, `task_stats`, and `task_stats_json` lowered onto the shared
  worker-pool/runtime thread helpers
- `@pure` now rejects direct effectful builtin calls and direct calls into
  non-pure Aether functions
- restricted `par { ... }` lowering for direct call statements, mapped onto
  shared spawn/join behavior
- half-open `for name in start..end { ... }` range loops lowered onto shared
  `for (...)` semantics
- compact `loop` forms now supported for condition loops, half-open range
  loops, and infinite loops lowered onto shared `while` / `for` constructs
- `mod`, `use`, and `export fn` lowered onto the shared module/import system
- inferred imported bindings from exported Aether `const` / `let` declarations
  in quoted `use` targets when their types are obvious to the frontend
- embedded `toon:` blocks that carry upstream TOON syntax and currently lower
  to `TOON`/`Text` string payloads
- compact `toon_*` helper calls lowered onto the shared `Json` library for
  parse/root/key/array access when yyjson support is available; this helper
  path currently covers parse/root/close cleanly for direct literal payloads
  and expects JSON-compatible `TOON` text
- keyed scalar helpers such as `toon_get_text(root, "name")` and
  `toon_get_int(root, "count")` lowered onto yyjson key lookup plus scalar
  extraction
- `has_toon()` as the compact Aether capability probe for TOON/yyjson support
- `ToonDoc` and `ToonNode` as source-level opaque handle types for parsed TOON
  documents and nodes, lowered onto the shared runtime representation
- `toon_typed_handles`: combines `has_toon()`, `ToonDoc`, `ToonNode`,
  handle navigation, keyed scalar reads, and explicit cleanup in one example
- `toon_rebind`: shows a `ToonNode` binding being reassigned from another
  node-producing helper while preserving the source-level handle kind rules
- `toon_scalar_bindings`: binds `toon_get_text` / `toon_get_int` /
  `toon_get_bool` results into matching `Text` / `Int` / `Bool` variables
- `toon_scalar_rebind`: reassigns a `Bool` binding from `toon_get_bool(...)`
  while preserving the declared scalar type
- `toon_scalar_alias`: reuses `Text` and `Int` scalar bindings through direct
  assignment while preserving Aether's source-level scalar types
- `toon_key_vars`: uses typed `Text` key bindings and an `Int` index binding
  with `toon_key(...)`, `toon_at(...)`, and `toon_get_text(...)`
- `toon_parse_payloads`: parses TOON from named `Text` / `TOON` payload
  bindings and then reads typed values from the parsed document
- `toon_parse_file`: parses TOON/JSON from a named `Text` file path binding
  and then reads typed values from the parsed document
- `toon_shape_scalars`: binds `toon_len(...)` and `toon_null_value(...)` into
  matching `Int` and `Bool` variables
- `toon_real_scalars`: binds `toon_get_real(...)` and `toon_real_value(...)`
  into `Real` variables
- `toon_type_checks`: uses `toon_type(...)` and `toon_is_*` helpers to inspect
  node kinds through Aether-native names
- `toon_presence_checks`: uses `toon_has_key(...)` and `toon_has_at(...)` for
  compact existence checks on objects and arrays
- `toon_defaults`: uses `toon_get_*_or(...)` helpers to read scalar values with
  typed fallback defaults
- `toon_safe_nested`: shows the safe guard pattern for nested object traversal
  where `_or` protects only the final keyed lookup, not the whole path
- `cost_annotations`: shows validated `@cost` budgets in both `ops` and `ms`
  forms without changing the shared backend
- `contract_layouts`: shows `@pre`, `@post`, and `@cost` surviving realistic
  blank-line and comment-separated layouts before a function declaration
- `tuple_post_contracts`: shows the narrow supported tuple-contract form where
  `@post` uses positional slots such as `result.0` and `result.1`
- `task_helpers`: shows the compact Aether task/thread alias surface along with
  the `has_ai()` capability probe, while still respecting `fx` around effectful
  worker launches
- `sleep_alias`: shows the compact `sleep(ms)` alias over the shared PSCAL
  `delay(ms)` builtin; it is effectful and therefore still belongs inside `fx`
- `builtin_queries`: shows `builtins_json(...)` and `builtin_info(...)` for
  structured capability discovery without inflating the language guide
- `ai_helpers`: shows the compact `ai_chat(...)` alias and the Aether AI
  capability probes without requiring a live call during the example run
- `inferred_decls`: shows compact initialized `const` / `let` declarations
  without explicit types, including helper-return and binding-alias inference
- `function_inference`: shows `let` inference from both local Aether function
  returns and imported Aether function signatures
- `object_inference`: shows `let` inference from `new Type()` plus typed method
  returns on a known binding
- `loop_forms`: shows `loop cond { ... }`, `loop name in start..end { ... }`,
  and bare `loop { ... }` forms with `break`
- `module_consts_demo`: shows inferred `let` bindings sourced from exported
  constants in another Aether module
- direct handle helpers such as `toon_key`, `toon_at`, `toon_len`,
  `toon_text_value`, `toon_int_value`, and `toon_free` lowered straight onto
  yyjson builtins
- simple variable-based `toon_parse(...)` flows when a local `Text` or `TOON`
  binding can still be resolved to a literal payload by the frontend rewrite
  layer
- `type Name { ... }` blocks with `field: Type;` members lowered onto the
  shared Rea class/object model
- compact object initialization with `let value: Type = Type { field: expr, ... };`
  lowered onto `new Type()` plus field assignments
- `self` as the Aether source spelling for the current object inside `type`
  methods, lowered onto the shared backend's `myself`
- `self_mutation`: shows `self.field = ...` mutation inside a method body
- `@pre` and `@post` lowered into runtime guards
- contract annotations now have frontend attachment checks too: `@pre`,
  `@post`, `@pure`, and `@cost` must all decorate the next function
- `@cost` is now frontend-validated: it must be a positive integer budget with
  an optional unit such as `ns`, `us`, `ms`, `s`, `op`/`ops`, or `step`/`steps`

- `number_formatting`: fixed-precision Real output (`value:width:precision`),
  real division, and a real mean over an `Int[]`
- `real_to_text`: the Real -> `Text` conversions side by side --
  `formatfloat(r, prec)` (exactly two arguments), `realtostr(r)` (always 6 dp),
  and the `println`-only `r:width:prec` form that cannot be bound to a `Text`.
  Written because the two spellings sit next to each other in the guide and get
  merged into a nonexistent three-argument `formatfloat(r, 0, prec)`, which
  compiles and only fails once the line runs
- `random_values`: `random()` -> `Real` in `[0, 1)` vs `random(n)` -> `Int` in
  `[0, n)`, and why assigning the no-argument form to an `Int` silently pins
  every "random" choice to `0`. Also notes the two seeding limits: whole-second
  `randomize()` granularity, and the per-thread seed that makes every `par`
  branch draw an identical stream
- `strings`: `Text` concatenation, `string_len`, `int_to_text`, and `==` equality
- `dynamic_arrays`: empty literal, append (`xs = xs + [v]`), indexed read/write,
  `length`, and iteration
- `nested_arrays`: `Int[][]` — literal 2-D construction, building a table row by
  row (`row = row + [v]`, then `table = table + [row]`), writing a cell through
  both indexes, jagged rows, and bounding the inner loop with
  `length(table[r])`. The DP-table shape: models reach for it, declare a 1-D
  `Int[]`, index it `x[i][j]`, and get an uncoded runtime error
- `text_processing`: the whole `Text` surface on one parsing job — `split`
  (empty fields are kept), `trim`, `pos`, `copy` vs the `s[a..b]` slice, and
  `ord`/`chr` to build the `to_upper` that does not exist. Written because
  **`pos` is the most-misused builtin in the language**: it is
  `pos(needle, haystack)`, and reversing the arguments returns `-1`, which reads
  as "not found" rather than "wrong order". It also returns `-1` when absent
  while `0` is a legitimate match at the first character, so the test is
  `>= 0`, never `> 0`
- `tuple_returns`: `-> (T, U)`, destructuring a direct call, positional `.0`/`.1`
  on a bound variable, `@post result.0`, and the record fallback. The closing
  comment lists each TUP-001 wall — chaining `.0` onto a call, an out-of-range
  index (caught at compile time), a method returning a tuple — all verified
- `bitwise_ops`: `& | ^ << >>` (and `xor`, the word spelling of `^`) driving
  flag masks, an XOR cipher that round-trips, `popCount`, and a bit-mixing hash.
  Includes the quiet precedence trap: `flags & mask != 0` parses as
  `flags & (mask != 0)` and yields an **Int**, not a Bool, without erroring
- `branching`: every branching form together — sequential `if` + `ret` beside
  the equivalent `else if` chain (both computed and compared at runtime), `if`
  as an *expression* with braced arms including inside a `println` argument,
  `continue` / `break`, and the three loop shapes side by side
- `file_io`: `File` is a handle type and the one binding declared without an
  initializer. `assign` attaches a path; the *mode* is chosen by which open call
  follows (`rewrite` truncates, `reset` reads, `append` extends). `readln(f, line)`
  fills `line` rather than returning it, and `eof(f)` is tested at the TOP of
  the loop. Cleans up after itself with `erase`
- `sockets`: a TCP client and server in one process joined by `par`. The names
  are one word — `socketcreate`, never `socket_create` or `tcp_socket`.
  `socketaccept`/`socketreceive` block, so the halves must run concurrently, and
  the listener is bound and listening *before* the `par` block or the client can
  race it. `socketreceive` returns an `MStream`, read via `mstreambuffer`
- `parsing`: `parse_int` / `parse_bool` / `parse_float`, and `split` into a `Text[]`
- `clamp_minmax`: `clamp(x, lo, hi)` plus `min` / `max` as accumulators instead
  of if-chains
- `recursion`: base-case + recursive-case helpers (factorial, summation)
- `text_var_builtins`: string builtins (`fileexists`, `getfattr`, `atoi`)
  accepting a `Text` *variable* argument, not just a string literal -- a `Text`
  variable is a `TYPE_UNICODE_STRING` at runtime, so strict `TYPE_STRING`
  builtins used to reject it

The backend remains the shared PSCAL compiler and VM.
