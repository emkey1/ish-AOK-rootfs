# iSH-AOK's native programs, after this image's own commands.
if [ -d /AOK/native ]; then
    case ":$PATH:" in
        *":/AOK/native:"*) ;;
        *) PATH="$PATH:/AOK/native"; export PATH ;;
    esac
fi
